

function AdminFeatures() {
    return (
      <div>
        AdminFeatures
      </div>
    )
  }
  
  export default AdminFeatures
  