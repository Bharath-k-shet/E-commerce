import AdminOrders from '../../components/admin-view/orders'

function AdminViewOrders() {
    return (
      <div>
        <AdminOrders/>
      </div>
    )
  }
  
  export default AdminViewOrders
  