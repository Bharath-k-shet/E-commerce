

function Unauth() {
  return (
    <div>
      fuck off
    </div>
  )
}

export default Unauth
